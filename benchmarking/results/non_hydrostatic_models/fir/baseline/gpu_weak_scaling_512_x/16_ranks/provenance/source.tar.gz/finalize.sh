#!/usr/bin/env bash
set -eo pipefail
mkdir -p /home/anditse/Oceananigans.jl/.runtime/tmp/weak512
export TMPDIR=/home/anditse/Oceananigans.jl/.runtime/tmp/weak512
export TMP=/home/anditse/Oceananigans.jl/.runtime/tmp/weak512
export TEMP=/home/anditse/Oceananigans.jl/.runtime/tmp/weak512
export OMPI_MCA_orte_tmpdir_base=/home/anditse/.ocean-tmp/weak512
source /home/anditse/Oceananigans.jl/benchmarking/scripts/env/modules.sh
export JULIA_NUM_THREADS=1 JULIA_NUM_GC_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export JULIA_PKG_PRECOMPILE_AUTO=0 JULIA_CUDA_MEMORY_POOL=none
export BENCHMARK_MPI_INIT=/home/anditse/Oceananigans.jl/benchmarking/scripts/env/drac_mpi.jl
module load python/3.11 scipy-stack/2025a
python3 /home/anditse/Oceananigans.jl/.runtime/studies/2026-11-12_fir_weak512/non_hydrostatic_models/fir/baseline/gpu_weak_scaling_512_x/run_metadata/scripts/benchmark_suite.py --study /home/anditse/Oceananigans.jl/.runtime/studies/2026-11-12_fir_weak512 --refresh
