#!/usr/bin/env python3
"""Serial Rondeau rerun with validated publication and adaptive resolution refinements."""
import fcntl
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import sys
from datetime import datetime, timezone

REPO = Path('/u/ajtse/Oceananigans.jl')
ROOT = Path(__file__).resolve().parent
STUDY = ROOT / 'rondeau'
PUBLISH = REPO / 'benchmarking/results/hydrostatic_free_surface_models/rondeau'
sys.path.insert(0, str(REPO / 'benchmarking/scripts'))
sys.path.insert(0, str(REPO / 'benchmarking/src'))
import benchmark_suite as runner
from suite.plan import configuration, SERIES
from suite.report import TERMINAL
from suite.catalog import publish_series, write_machine_report

ORDER = ('gpu_resolution', 'gpu_scaling_super_fine', 'gpu_partition_super_fine',
         'gpu_nsight_scaling_super_fine', 'gpu_scaling_super_super_fine',
         'gpu_weak_scaling_super_fine', 'gpu_scaling_super_super_super_fine',
         'cpu_partition_cores_super_fine', 'cpu_mpi_scaling_super_fine', 'cpu_resolution')


def note(message):
    print(datetime.now(timezone.utc).isoformat(), message, flush=True)


def save_status(series, state, case=''):
    runner.atomic_json(ROOT / 'progress.json', dict(series=series, state=state, case=case,
        updated_at=datetime.now(timezone.utc).isoformat(), pid=os.getpid(), study=str(STUDY)))


def classify_failure(folder, case):
    if case['state'] != 'FAILED':
        return
    path = folder / case['id']
    logs = [path / 'job.out', *path.glob('rank_*/profile.out')]
    output = '\n'.join(p.read_text(errors='replace') for p in logs if p.exists())
    if 'outofgpumemoryerror' in output.lower() or 'out of gpu memory' in output.lower():
        case['details'] = 'GPU VRAM exhausted; see original job.out and profiler logs in scratch study'
    elif 'OutOfMemoryError' in output or 'Cannot allocate memory' in output:
        case['details'] = ('Host allocation failed under the available-memory address-space limit; '
                           'see allocation.out and job.out in scratch study')


def append_notes(folder, data):
    target = PUBLISH / folder.name
    target.mkdir(parents=True, exist_ok=True)
    if not (target / 'suite.json').exists():
        runner.atomic_json(target / 'suite.json', dict(server=data['server'], cases=[], curated=True))
        (target / 'plot.md').write_text('# ' + folder.name + '\n\nNo completed, validated measurements.\n')
    path = target / 'plot.md'
    previous = path.read_text().split('<!-- current-rerun -->')[0].rstrip()
    accepted = [c for c in data['cases'] if c['state'] == 'COMPLETED']
    lines = ['<!-- current-rerun -->', '## Current rerun', '',
             'Study: `' + str(STUDY) + '`. Original commands, allocation scripts and failure logs remain there.',
             'Two untimed steps, then five synchronized windows of ten steps; one Julia thread per MPI rank.',
             'This rerun validates all rank results, MPI communication, distinct resources and finite model fields.', '']
    if accepted:
        largest = max(accepted, key=lambda c: __import__('math').prod(c['configuration']['global_resolution'])
                      if folder.name.endswith('resolution') else c['ranks'])
        lines += ['Highest completed case: **' + largest['id'] + '**.', '']
    lines += ['| Case | Global resolution | MPI partition | Outcome | Details |', '|---|---|---|---|---|']
    for case in data['cases']:
        if case['state'] == 'PLANNED':
            continue
        cfg = case.get('configuration', {})
        grid = ' × '.join(map(str, cfg.get('global_resolution', [])))
        partition = ' × '.join(map(str, case.get('partition') or []))
        detail = case['details'].replace('|', '/').replace('\n', ' ')
        lines.append('| ' + ' | '.join([case['id'], grid, partition, case['state'], detail]) + ' |')
    path.write_text(previous + '\n\n' + '\n'.join(lines) + '\n')


def machine_notes():
    write_machine_report(PUBLISH)
    lines = ['## README series rerun', '',
             'Host: Rondeau; 128 physical CPU cores and four NVIDIA A100-SXM4-40GB GPUs.',
             'Serial execution prevents benchmark cases from competing with one another.',
             'Full study and live logs: `' + str(ROOT) + '`.',
             'GPU resolution stops at the first observed VRAM failure. CPU resolution doubles all three grid dimensions until a host allocation failure; available RAM bounds each process address space.',
             'Historical measurements retain their original validation labels until comparable reruns complete.', '',
             '| Standard series | Completed new cases | Pending cases | Report |', '|---|---:|---:|---|']
    for series in ORDER:
        data = json.loads((STUDY / series / 'suite.json').read_text())
        accepted = sum(c['state'] == 'COMPLETED' for c in data['cases'])
        pending = sum(c['state'] not in TERMINAL for c in data['cases'])
        report = '[' + series + '](' + series + '/plot.md)' if (PUBLISH / series / 'plot.md').exists() else 'Pending'
        lines.append('| ' + series + ' | ' + str(accepted) + ' | ' + str(pending) + ' | ' + report + ' |')
    with (PUBLISH / 'plot.md').open('a') as stream:
        stream.write('\n' + '\n'.join(lines) + '\n')


def publish(folder, data):
    for case in data['cases']:
        classify_failure(folder, case)
    runner.atomic_json(folder / 'suite.json', data)
    publish_series(folder, PUBLISH / folder.name)
    append_notes(folder, data)
    write_machine_report(STUDY)
    machine_notes()


def commit(folder):
    try:
        runner.commit_artifacts(PUBLISH / folder.name)
    except RuntimeError as error:
        note('Artifact commit deferred: ' + str(error))


def run_case(folder, data, case):
    script = runner.group_script(folder, data['server'], [case])
    note('Running ' + folder.name + '/' + case['id'])
    save_status(folder.name, 'RUNNING', case['id'])
    command = (folder / case['id'] / 'command.txt').read_text().strip()
    with (ROOT / 'commands.log').open('a') as stream:
        stream.write(datetime.now(timezone.utc).isoformat() + ' ' + command + '\n')
    with (script.parent / 'allocation.out').open('w') as log:
        process = subprocess.Popen(['bash', str(script)], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        runner.atomic_json(ROOT / 'active_allocation.json', dict(pid=process.pid, series=folder.name, case=case['id']))
        case.update(state='RUNNING', details='Local allocation running; waiting for synchronized timings')
        runner.atomic_json(folder / 'suite.json', data)
        try:
            process.wait(timeout=data['server']['case_timeout_seconds'])
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            case.update(state='TIMEOUT', details='Local allocation exceeded the recorded 14-day case time limit')
        if not (folder / case['id'] / 'finished.txt').exists() and case['state'] != 'TIMEOUT':
            case.update(state='INTERRUPTED', details='Allocation exited without a completion marker; see allocation.out')
    (ROOT / 'active_allocation.json').unlink(missing_ok=True)
    runner.refresh(folder, data, query_slurm=False)
    classify_failure(folder, case)
    publish(folder, data)
    note(case['id'] + ': ' + case['state'] + ' ' + case['details'])
    commit(folder)


def alternative_baseline(folder, data, case):
    series = folder.name
    scaling = series.startswith('gpu_scaling_') or series in {'gpu_nsight_scaling_super_fine', 'gpu_weak_scaling_super_fine'}
    if not scaling or any(c['state'] == 'COMPLETED' for c in data['cases']):
        return
    requested = case['configuration']['baseline_ranks']
    if case['ranks'] == requested:
        return
    if not any(c['state'] == 'FAILED' and 'VRAM exhausted' in c['details'] for c in data['cases']):
        return
    note('Attempting measured alternative baseline at ' + str(case['ranks']) + ' GPUs after smaller baseline exhausted VRAM')
    for pending in data['cases']:
        if pending['state'] != 'PLANNED' or 'configuration' not in pending:
            continue
        pending['configuration']['baseline_ranks'] = case['ranks']
        destination = folder / pending['id']
        runner.atomic_json(destination / 'configuration.json', pending['configuration'])
        (destination / 'configuration.md').write_text(runner.config_markdown(pending['configuration']) +
            '\nAlternative measured efficiency baseline: ' + str(case['ranks']) + ' GPUs; smaller baseline exhausted VRAM.\n')


def extend_resolution(folder, data):
    while all(c['state'] == 'COMPLETED' for c in data['cases']):
        previous = data['cases'][-1]['configuration']
        size = [2 * n for n in previous['global_resolution']]
        name = 'x'.join(map(str, size))
        cfg = configuration(folder.name, 1, name, global_resolution=size)
        case = dict(id=name, series=folder.name, ranks=1, grid_name=name,
                    partition=cfg['partition'], configuration=cfg, state='PLANNED', details='', job_id='')
        destination = folder / name
        destination.mkdir()
        runner.atomic_json(destination / 'configuration.json', cfg)
        (destination / 'configuration.md').write_text(runner.config_markdown(cfg))
        data['cases'].append(case)
        run_case(folder, data, case)
    failed = next((c for c in data['cases'] if c['state'] != 'COMPLETED'), None)
    if failed:
        note('Resolution stopping case: ' + failed['id'] + '=' + failed['state'] + ': ' + failed['details'])


def run_series(series):
    folder = STUDY / series
    with (folder / '.suite.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        data = json.loads((folder / 'suite.json').read_text())
        runner.refresh(folder, data, query_slurm=False)
        if any(c['state'] == 'RUNNING' for c in data['cases']):
            raise RuntimeError('An existing allocation is still active; resume after it completes')
        if series == 'cpu_mpi_scaling_super_fine':
            data['cases'].sort(key=lambda c: -c['ranks'])
        shutil.copy2(__file__, folder / 'run_metadata/scripts/run_study.py')
        shutil.copy2(REPO / 'benchmarking/src/suite/report.py', folder / 'run_metadata/src/suite/report.py')
        data['submitted_at'] = data.get('submitted_at') or datetime.now(timezone.utc).isoformat()
        publish(folder, data)
        for case in data['cases']:
            if case['state'] != 'PLANNED':
                continue
            if series.endswith('resolution') and any(c['state'] == 'FAILED' for c in data['cases']):
                case.update(state='NOT_RUN', details='Earlier resolution failed; inspect its preserved failure evidence')
                continue
            alternative_baseline(folder, data, case)
            run_case(folder, data, case)
        if series.endswith('resolution'):
            extend_resolution(folder, data)
        runner.refresh(folder, data, query_slurm=False)
        publish(folder, data)
        commit(folder)
        save_status(series, 'FINISHED')
        note(series + ' reached terminal states')


os.chdir(REPO)
with (ROOT / '.run.lock').open('a') as run_lock:
    fcntl.flock(run_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        for series in ORDER:
            run_series(series)
        save_status('all', 'FINISHED')
        note('All standard series reached terminal states; reports distinguish memory, geometry, resource and execution limits.')
    except BaseException as error:
        save_status('driver', 'ERROR: ' + repr(error))
        note('ERROR: ' + repr(error))
        raise
