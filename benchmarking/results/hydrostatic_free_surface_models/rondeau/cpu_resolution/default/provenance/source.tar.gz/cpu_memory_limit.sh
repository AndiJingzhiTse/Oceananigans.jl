#!/usr/bin/env bash
# Bound each CPU resolution process to currently available host memory.
# This makes oversized allocations fail in Julia instead of exhausting the host.
set -euo pipefail
benchmark_memory_kib=$(python3 -c 'from pathlib import Path; print(next(int(line.split()[1]) for line in Path("/proc/meminfo").read_text().splitlines() if line.startswith("MemAvailable:")))')
export BENCHMARK_HOST_ADDRESS_SPACE_LIMIT_KIB="$benchmark_memory_kib"
printf 'Host address-space limit: %s KiB (MemAvailable before this case)\n' "$benchmark_memory_kib"
ulimit -v "$benchmark_memory_kib"
