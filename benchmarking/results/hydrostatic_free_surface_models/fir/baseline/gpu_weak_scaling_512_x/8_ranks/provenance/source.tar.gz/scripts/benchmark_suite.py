#!/usr/bin/env python3
"""Run standard benchmark series locally or submit them to Slurm."""
import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shlex
import signal
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent
sys.path.insert(0, str(ROOT / 'src'))

from suite.plan import SERIES, ALL_SERIES, GRIDS, MODEL_FOLDERS, build_plan, allocation_groups, machine_series
from suite.servers import load_series, series_definitions
from suite.execution import describe_adapter, snapshot_adapter
from suite.backends import backend
from suite.report import TERMINAL, validate, write_report, write_model_comparison
from suite.catalog import MACHINES, write_machine_report, write_series_report, publish_series


def command(args, **kwargs):
    return subprocess.run([str(a) for a in args], text=True, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, timeout=60, **kwargs)


def atomic_json(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(path)


def load_server(path=None, model_type=None, execution_mode=None):
    user = json.loads(Path(path).read_text()) if path else {}
    if model_type:
        user['model_type'] = model_type
    if execution_mode:
        user['execution_mode'] = execution_mode
    backend = user.get('backend', 'local')
    assigned_cpus = os.sched_getaffinity(0) if hasattr(os, 'sched_getaffinity') else range(os.cpu_count())
    physical_cores = set()
    for cpu in assigned_cpus:
        topology = Path(f'/sys/devices/system/cpu/cpu{cpu}/topology')
        if topology.exists():
            physical_cores.add(((topology / 'physical_package_id').read_text().strip(),
                                (topology / 'core_id').read_text().strip()))
    cpu_capacity = len(physical_cores) or len(assigned_cpus)
    gpu_info = command(['nvidia-smi', '--query-gpu=uuid', '--format=csv,noheader']) if shutil.which('nvidia-smi') else None
    gpu_capacity = len(gpu_info.stdout.strip().splitlines()) if gpu_info and not gpu_info.returncode else 0
    visible = os.environ.get('CUDA_VISIBLE_DEVICES')
    if visible is not None:
        gpu_capacity = min(gpu_capacity, len([v for v in visible.split(',') if v and v != '-1']))
    if backend == 'slurm' and any(key not in user for key in ('max_cpu_cores', 'max_gpus', 'cpu_cores_per_node', 'gpus_per_node')):
        raise ValueError('Slurm config must state max_cpu_cores, max_gpus, cpu_cores_per_node and gpus_per_node')
    machine = Path(path).stem if path and Path(path).stem in MACHINES else 'Andi-5070ti'
    server = dict(machine=machine,
                  backend=backend, project=str(ROOT), julia='julia', mpi=['mpiexec'],
                  max_cpu_cores=cpu_capacity, max_gpus=gpu_capacity,
                  cpu_cores_per_node=cpu_capacity, gpus_per_node=max(1, gpu_capacity),
                  gpu_host_cores=8, cpu_account='', gpu_account='', cpu_partition='', gpu_partition='',
                  gpu_type='', cpu_constraint='', exclusive_cpu=True, environment_script='', mpi_init='',
                  cpu_time='03:00:00', gpu_time='00:45:00', partition_time='03:00:00',
                  gpu_memory='128G', cpu_memory_base_gb=64, cpu_memory_per_rank_gb=4,
                  cpu_sbatch_extra=[], gpu_sbatch_extra=[],
                  trace_root=str(ROOT / 'results' / MODEL_FOLDERS[user.get('model_type', 'HydrostaticFreeSurfaceModel')] /
                                 user.get('machine', machine) / user.get('execution_mode', 'baseline')),
                  case_timeout_seconds=86400, matplotlib=True, python='python3', report_modules=[],
                  reference_suites=[], replacement_suites=[], environment={}, gpu_scaling_partition='balanced',
                  model_type='HydrostaticFreeSurfaceModel', model_setup='earth_ocean', comparison_suites=[], comparison_report='',
                  execution_mode='baseline', profile_layout='study', series_file='', series_definitions=None,
                  dagger_adapter='', dagger_options={}, execution_adapter=None, workflow_root='', trace_namespace='')
    server.update(pressure_preconditioner='DiagonallyDominantPreconditioner',
                  pressure_max_iterations=5000, pressure_diagnostics=False,
                  pressure_preserve_residual=False, pressure_check_true_residual=True, separate_partitions=False)
    server['cpu_time_overrides'] = {}
    server['full_gpu_nodes'] = False
    if user.get('model_type') == 'NonhydrostaticModel':
        server.update(pressure_preconditioner='LocalFFTPreconditioner', separate_partitions=True,
                      full_gpu_nodes=backend == 'slurm', cpu_time='08:00:00', gpu_time='06:00:00',
                      cpu_time_overrides={'1': '72:00:00', '3': '48:00:00', '6': '24:00:00', '12': '12:00:00'})
    unknown = set(user) - set(server)
    if unknown:
        raise ValueError('Unknown server settings: ' + ', '.join(sorted(unknown)))
    server.update(user)
    if server['dagger_adapter']:
        adapter_path = Path(os.path.expandvars(server['dagger_adapter'])).expanduser()
        if not adapter_path.is_absolute():
            adapter_path = (Path(path).resolve().parent if path else REPO) / adapter_path
        server['dagger_adapter'] = str(adapter_path.resolve())
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*', server['machine']):
        raise ValueError('Server name must be a safe directory name')
    if server['backend'] not in ('local', 'slurm'):
        raise ValueError('backend must be local or slurm')
    if any(not isinstance(server[k], int) or server[k] < 1 for k in ('max_cpu_cores', 'cpu_cores_per_node', 'gpus_per_node', 'gpu_host_cores')):
        raise ValueError('CPU capacity and per-node resource counts must be positive integers')
    if not isinstance(server['max_gpus'], int) or server['max_gpus'] < 0:
        raise ValueError('max_gpus must be a nonnegative integer')
    for key in ('mpi', 'cpu_sbatch_extra', 'gpu_sbatch_extra', 'report_modules', 'reference_suites', 'replacement_suites', 'comparison_suites'):
        if not isinstance(server[key], list) or any(not isinstance(a, str) for a in server[key]):
            raise ValueError(f'{key} must be an array of command arguments')
    if server['gpu_scaling_partition'] not in ('balanced', 'x'):
        raise ValueError('gpu_scaling_partition must be balanced or x')
    if server['model_type'] not in MODEL_FOLDERS:
        raise ValueError('Unknown model_type')
    if server['model_setup'] not in ('earth_ocean', 'rectilinear_buoyancy'):
        raise ValueError('Unknown model_setup')
    if server['execution_mode'] not in ('baseline', 'dagger'):
        raise ValueError('execution_mode must be baseline or dagger')
    if server['profile_layout'] not in ('study', 'series'):
        raise ValueError('profile_layout must be study or series')
    if server['trace_namespace'] and not re.fullmatch(r'[A-Za-z0-9_-]+', server['trace_namespace']):
        raise ValueError('Trace namespace must be a safe directory name')
    if server['series_file']:
        series_path = Path(server['series_file'])
        if not series_path.is_absolute():
            series_path = Path(path).resolve().parent / series_path
        server['series_file'] = str(series_path.resolve())
        server['series_definitions'] = load_series(series_path)
    else:
        server['series_definitions'] = series_definitions(server)
    if server['pressure_preconditioner'] not in ('DiagonallyDominantPreconditioner', 'ColumnwiseTridiagonalPreconditioner', 'VerticalLinePreconditioner', 'LocalFFTPreconditioner'):
        raise ValueError('Unknown pressure_preconditioner')
    if not isinstance(server['pressure_max_iterations'], int) or server['pressure_max_iterations'] < 1:
        raise ValueError('pressure_max_iterations must be a positive integer')
    if any(not isinstance(server[k], bool) for k in ('pressure_diagnostics', 'pressure_preserve_residual', 'pressure_check_true_residual', 'separate_partitions', 'full_gpu_nodes')):
        raise ValueError('pressure_diagnostics and separate_partitions must be boolean')
    if (not isinstance(server['cpu_time_overrides'], dict) or
            any(not re.fullmatch(r'[1-9]\d*', k) or not isinstance(v, str) or
                not re.fullmatch(r'(?:\d+-)?\d{1,3}:\d{2}:\d{2}', v)
                for k, v in server['cpu_time_overrides'].items())):
        raise ValueError('cpu_time_overrides must map rank counts to Slurm time limits')
    if not isinstance(server['environment'], dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in server['environment'].items()):
        raise ValueError('environment must map variable names to string values')
    for key in ('project', 'trace_root', 'environment_script', 'mpi_init', 'comparison_report'):
        if server[key]:
            server[key] = str(Path(os.path.expandvars(server[key])).expanduser().resolve())
    server['reference_suites'] = [str(Path(os.path.expandvars(p)).expanduser().resolve())
                                for p in server['reference_suites']]
    server['replacement_suites'] = [str(Path(os.path.expandvars(p)).expanduser().resolve())
                                  for p in server['replacement_suites']]
    server['comparison_suites'] = [str(Path(os.path.expandvars(p)).expanduser().resolve())
                                  for p in server['comparison_suites']]
    return server


def snapshot(folder, server):
    metadata = folder / 'run_metadata'
    metadata.mkdir()
    # Executable planner/worker snapshot: queued jobs do not depend on later edits.
    (metadata / 'scripts').mkdir()
    shutil.copy2(ROOT / 'scripts/benchmark_suite.py', metadata / 'scripts/benchmark_suite.py')
    shutil.copy2(ROOT / 'scripts/compare_dagger.py', metadata / 'scripts/compare_dagger.py')
    for name in ('Project.toml', 'Manifest.toml', 'LocalPreferences.toml'):
        source = Path(server['project']) / name
        if source.exists():
            shutil.copy2(source, metadata / name)
    shutil.copytree(ROOT / 'src', metadata / 'src', ignore=shutil.ignore_patterns('__pycache__'))
    if server.get('execution_adapter'):
        snapshot_adapter(metadata, server)
    # Keep the resolved workload next to the executable snapshot, independently
    # of the mutable server files or paths on the submitting machine.
    atomic_json(metadata / 'series.json', server.get('series_definitions') or {})
    (metadata / 'revision.txt').write_text(command(['git', '-C', REPO, 'rev-parse', 'HEAD']).stdout)
    (metadata / 'working_tree.txt').write_text(command(['git', '-C', REPO, 'status', '--short']).stdout)
    for setting in ('environment_script', 'mpi_init'):
        if server[setting]:
            source = Path(server[setting])
            if not source.is_file():
                raise ValueError(f'{setting} does not exist: {source}')
            shutil.copy2(source, metadata / source.name)
    for tool in ('lscpu', 'nvidia-smi'):
        if shutil.which(tool):
            (metadata / f'{tool}.txt').write_text(command([tool]).stdout)
    return metadata


def config_markdown(config):
    dispatch = ('Four independent models, one GPU and MPI rank per model; '
                'Dagger schedules complete simulations, baseline uses concurrent Distributed calls.'
                if config.get('ensemble_size') else
                f"Adapter {config.get('execution_adapter', {}).get('id', 'legacy')}; "
                f"timing contract {config.get('execution_adapter', {}).get('timing_contract', 'legacy')}.")
    return ('# Benchmark configuration\n\n'
            f"Series: {config['series']}. Device: {config['device']}; MPI ranks: {config['ranks']}; one thread/rank.\n"
            f"Model: {config.get('model_type', 'HydrostaticFreeSurfaceModel')}; surface: {config.get('free_surface', 'SplitExplicitFreeSurface')}.\n"
            f"Execution: {config.get('execution_mode', 'baseline')}; {dispatch}\n"
            f"Grid: {config['grid_name']}, {' × '.join(map(str, config['global_resolution']))}, {config['grid_type']}.\n"
            f"Partition: {' × '.join(map(str, config['partition']))}.\n"
            f"Local resolution: x {min(config['x_sizes'])}–{max(config['x_sizes'])}, y {min(config['y_sizes'])}–{max(config['y_sizes'])}, z {config['global_resolution'][2]}.\n"
            f"Domain extent (m): {config.get('domain_extent_m', 'see model setup')}; cell spacing (m): {config.get('cell_spacing_m', 'see model setup')}; topology: {config.get('topology', 'see model setup')}.\n"
            f"Float64; momentum {config['momentum_advection']}, tracer advection {config['tracer_advection']}, closure={config['closure']}, tracers={config['tracers']}, {config['timestepper']}.\n"
            f"Buoyancy={config.get('buoyancy')}; Coriolis={config.get('coriolis')}; initial condition={config.get('initial_condition', 'seeded Earth-ocean fields')}.\n"
            f"Viscosity={config.get('viscosity')}; diffusivity={config.get('diffusivity')} m²/s; pressure solver={config.get('pressure_solver')}.\n"
            f"Pressure preconditioner={config.get('pressure_preconditioner')}; iteration cap={config.get('pressure_max_iterations')}; relative/absolute tolerances={config.get('pressure_reltol')}/{config.get('pressure_abstol')}.\n"
            f"Δt={config['dt']} s; free-surface substeps={config['free_surface_substeps']} requested; extend_halos={config['extend_free_surface_halos']}.\n"
            f"Initial-condition seed={config.get('initial_condition_seed')} plus MPI rank when set.\n"
            f"Two untimed steps, {config['samples']} windows of {config['time_steps']} steps. Profile={config['profile']}.\n")


def prepare(folder, server, selected):
    if len(selected) != 1:
        raise ValueError('Each stored suite belongs to one benchmark series')
    if (folder / 'suite.json').exists():
        raise ValueError('Suite exists; use --resume or --refresh, or choose a fresh output directory')
    folder.mkdir(parents=True, exist_ok=True)
    server['execution_adapter'] = describe_adapter(server)
    cases = build_plan(server, selected)
    for case in cases:
        case['id'] = case['id'].split('/')[-1]
        destination = folder / case['id']
        destination.mkdir(parents=True)
        if 'configuration' in case:
            if not case['configuration'].get('ensemble_size'):
                case['configuration']['execution_adapter'] = server['execution_adapter']
            atomic_json(destination / 'configuration.json', case['configuration'])
            (destination / 'configuration.md').write_text(config_markdown(case['configuration']))
        else:
            grid = ' × '.join(map(str, GRIDS[case['grid_name']])) if case['grid_name'] in GRIDS else case['grid_name']
            (destination / 'limit.md').write_text(f"# Unavailable partition\n\nGlobal grid: {grid} LatitudeLongitudeGrid.\nRanks: {case['ranks']}; partition: {case['partition']}.\n{case['details']}\n")
    snapshot(folder, server)
    data = dict(server=server, cases=cases, submitted_at=None)
    atomic_json(folder / 'suite.json', data)
    write_report(folder, cases, plotting=False, reference_suites=server.get('reference_suites', []),
                 replacement_suites=server.get('replacement_suites', []))
    return data


def launch_command(server, config, case_dir, metadata, trace_root):
    if config.get('ensemble_size'):
        from suite.ensemble import launch_command as ensemble_launch
        return ensemble_launch(server, config, case_dir, metadata)
    rank_script = metadata / 'src/suite/rank.sh'
    worker = metadata / 'src/suite/worker.jl'
    traces = trace_root / config['series']
    if server.get('profile_layout') == 'series':
        traces = traces / 'raw_profiles'
        if server.get('trace_namespace'):
            traces = traces / server['trace_namespace']
    args = ['bash', str(rank_script), str(case_dir), server['project'], str(worker),
            str(traces / case_dir.name), server['julia']]
    return backend(server).launch(server, config, args)


def environment_lines(server):
    lines = ['set -eo pipefail']
    environment = dict(server['environment'])
    runtime = str(Path(server['trace_root']).parent / '.runtime')
    if 'TMPDIR' not in environment:
        alias = Path.home() / '.ocean-tmp' / hashlib.sha256(runtime.encode()).hexdigest()[:12]
        lines += ['mkdir -p ' + shlex.quote(runtime) + ' ' + shlex.quote(str(alias.parent)),
                  'if [ ! -e ' + shlex.quote(str(alias)) + ' ] && [ ! -L ' + shlex.quote(str(alias)) +
                  ' ]; then ln -s ' + shlex.quote(runtime) + ' ' + shlex.quote(str(alias)) + '; fi',
                  'test ' + shlex.quote(str(alias)) + ' -ef ' + shlex.quote(runtime)]
        environment['TMPDIR'] = str(alias)
    for name in ('TMP', 'TEMP', 'OMPI_MCA_orte_tmpdir_base'):
        environment.setdefault(name, environment['TMPDIR'])
    lines.append('mkdir -p ' + shlex.quote(os.path.expandvars(os.path.expanduser(environment['TMPDIR']))))
    for key, value in environment.items():
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', key) or key in {'HOME', 'CODEX_HOME'}:
            raise ValueError('Invalid environment variable name: ' + key)
        lines.append('export ' + key + '=' + shlex.quote(os.path.expandvars(os.path.expanduser(value))))
    if server['environment_script']:
        lines.append('source ' + shlex.quote(server['environment_script']))
    lines += ['export JULIA_NUM_THREADS=1 JULIA_NUM_GC_THREADS=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1',
              'export JULIA_PKG_PRECOMPILE_AUTO=0 JULIA_CUDA_MEMORY_POOL=none']
    if server['mpi_init']:
        lines.append('export BENCHMARK_MPI_INIT=' + shlex.quote(server['mpi_init']))
    return lines


def group_script(folder, server, cases):
    first = cases[0]
    destination = folder / first['id'] / 'allocation.sh'
    metadata = folder / 'run_metadata'
    model_type = first['configuration'].get('model_type', 'HydrostaticFreeSurfaceModel')
    study = hashlib.sha256(str(folder.parent).encode()).hexdigest()[:16]
    traces = Path(server['trace_root']) / MODEL_FOLDERS[model_type] / server['machine'] / study / folder.name
    if server.get('profile_layout') == 'series':
        traces = Path(server['trace_root'])
    lines = ['#!/usr/bin/env bash', *environment_lines(server), 'failed=0']
    lines += ['if type module >/dev/null 2>&1; then module -t list > ' + shlex.quote(str(destination.parent / 'modules.txt')) + ' 2>&1; fi',
              shlex.join([server['julia'], '--version']) + ' > ' + shlex.quote(str(destination.parent / 'julia_version.txt')),
              'if command -v nsys >/dev/null; then nsys --version > ' + shlex.quote(str(destination.parent / 'nsight_version.txt')) + '; fi']
    lines += backend(server).allocation_evidence(server, first['configuration'], destination)
    for case in cases:
        path = folder / case['id']
        if server.get('workflow_root'):
            from suite.storage import runtime_environment
            for name, value in runtime_environment(folder / '.runtime' / case['id']).items():
                lines.append('export ' + name + '=' + shlex.quote(value))
        launch = launch_command(server, case['configuration'], path, metadata, traces)
        (path / 'command.txt').write_text(shlex.join(launch) + '\n')
        prefix = shlex.quote(str(path))
        verify = (shlex.join([server['python'], str(metadata / 'scripts/benchmark_suite.py'),
                             '--verify-source', server['workflow_root'], '--verify-suite', str(folder)]) if server.get('workflow_root') else 'true')
        # Both checks run inside the allocation; a change during a case excludes
        # its timings rather than silently recording a different implementation.
        lines += [f'date -u +%FT%TZ > {prefix}/started.txt', 'status=0',
                  f'{verify} > {prefix}/source_before.out 2>&1 || status=$?',
                  f'if [[ "$status" == 0 ]]; then {shlex.join(launch)} > {prefix}/job.out 2>&1 || status=$?; fi',
                  f'if [[ "$status" == 0 ]]; then {verify} > {prefix}/source_after.out 2>&1 || status=$?; fi',
                  f'printf "%s\\n" "$status" > {prefix}/exit_code.txt',
                  f'date -u +%FT%TZ > {prefix}/finished.txt',
                  'if [[ "$status" != 0 ]]; then failed=1; fi']
    lines += ['exit "$failed"']
    destination.write_text('\n'.join(lines) + '\n')
    return destination


def sbatch_command(server, group, script):
    from suite.backends import sbatch_command as build_sbatch
    return build_sbatch(server, group, script)


def execute(folder, data, case_ids=None, on_start=None):
    server, cases = data['server'], data['cases']
    selected = cases if case_ids is None else [c for c in cases if c['id'] in case_ids]
    for key, group in allocation_groups(selected, server.get('separate_partitions', False)).items():
        script = group_script(folder, server, group)
        backend(server).execute_group(sys.modules[__name__], folder, data, group, script, on_start)
        atomic_json(folder / 'suite.json', data)
    backend(server).finalize(sys.modules[__name__], folder, data)
    data['submitted_at'] = datetime.now(timezone.utc).isoformat()
    atomic_json(folder / 'suite.json', data)
    refresh(folder, data)


def submit_finalizer(folder, data):
    from suite.backends import submit_finalizer as finalize
    return finalize(sys.modules[__name__], folder, data)


def refresh(folder, data, query_slurm=True):
    if data.get('curated'):
        write_series_report(folder, data['cases'])
        return True
    cases = data['cases']
    records = {}
    ids = sorted({c['job_id'] for c in cases if c['job_id'] and c['state'] not in TERMINAL})
    if query_slurm:
        records = backend(data['server']).accounting(sys.modules[__name__], folder, ids)
    for case in cases:
        destination = folder / case['id']
        if case['state'] in {'RESOURCE_LIMIT', 'GEOMETRY_LIMIT'}:
            continue
        # Reuse a successfully validated snapshot. Explicit --revalidate can
        # remove this cache when artifacts have been edited or relocated.
        if case['state'] == 'COMPLETED' and 'measurement' in case:
            continue
        if (destination / 'finished.txt').exists():
            status = (destination / 'exit_code.txt').read_text().strip()
            case.update(state='FAILED', details=f'Execution/export exit {status}; see job.out and rank logs')
            if status == '0':
                try:
                    case['measurement'] = validate(destination, case['configuration'])
                    case.update(state='COMPLETED', details='Rank results, finite fields and resource placement verified')
                except (ValueError, KeyError, OSError, TypeError) as error:
                    case.update(state='INVALID_RESULTS', details=str(error))
        elif case['job_id'] in records:
            state, detail = records[case['job_id']]
            if state in TERMINAL and not (destination / 'started.txt').exists():
                case.update(state='NOT_RUN', details=f'Case never started; allocation {state}: {detail}')
            else:
                case.update(state='INTERRUPTED' if state == 'COMPLETED' else state, details=detail)
        elif (destination / 'started.txt').exists() and case['state'] not in TERMINAL:
            case.update(state='RUNNING', details='Started; waiting for completion marker')
    atomic_json(folder / 'suite.json', data)
    write_report(folder, cases, plotting=data['server']['matplotlib'],
                 reference_suites=data['server'].get('reference_suites', []),
                 replacement_suites=data['server'].get('replacement_suites', []))
    if data['server'].get('comparison_report'):
        write_model_comparison(Path(data['server']['comparison_report']), folder, cases,
                               data['server'].get('comparison_suites', []))
    return all(c['state'] in TERMINAL for c in cases)


def commit_artifacts(folder):
    repository = command(['git', '-C', folder, 'rev-parse', '--show-toplevel'])
    if repository.returncode:
        raise RuntimeError('--commit requires an output directory inside a Git repository')
    repo = Path(repository.stdout.strip())
    common = command(['git', '-C', repo, 'rev-parse', '--git-common-dir'])
    git_dir = (repo / common.stdout.strip()).resolve()
    with (git_dir / 'benchmark_artifacts.lock').open('a') as lock:
        # Several suites can finish at once; serialize their index mutations.
        fcntl.flock(lock, fcntl.LOCK_EX)
        return commit_artifacts_locked(folder, repo)


def commit_artifacts_locked(folder, repo):
    if command(['git', '-C', repo, 'diff', '--cached', '--quiet']).returncode:
        raise RuntimeError('Index contains unrelated changes; refusing automatic commit')
    staged = command(['git', '-C', repo, 'add', '--', str(folder.relative_to(repo))])
    if staged.returncode:
        raise RuntimeError(staged.stdout)
    data = json.loads((folder / 'suite.json').read_text())
    if (folder.parent / 'plot.md').is_file():
        result = command(['git', '-C', repo, 'add', '--', str((folder.parent / 'plot.md').relative_to(repo))])
        if result.returncode:
            raise RuntimeError(result.stdout)
    comparison = data['server'].get('comparison_report')
    if comparison:
        result = command(['git', '-C', repo, 'add', '--', str(Path(comparison).relative_to(repo))])
        if result.returncode:
            raise RuntimeError(result.stdout)
    if command(['git', '-C', repo, 'diff', '--cached', '--quiet']).returncode:
        committed = command(['git', '-C', repo, 'commit', '-m', 'Record validated benchmark suite results and job outcomes'])
        if committed.returncode:
            raise RuntimeError(committed.stdout)
        print(committed.stdout, flush=True)


def main():
    if '--verify-source' in sys.argv:
        from suite.workflow import verify_source
        suite = Path(sys.argv[sys.argv.index('--verify-suite') + 1]) if '--verify-suite' in sys.argv else None
        verify_source(Path(sys.argv[sys.argv.index('--verify-source') + 1]), suite)
        return
    if any(arg.split('=', 1)[0] in ('--study', '--models', '--modes', '--combinations', '--all', '--execute', '--help', '-h') for arg in sys.argv[1:]):
        from suite.workflow import main as workflow_main
        return workflow_main(sys.modules[__name__])
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, help='Server resource and environment JSON file')
    parser.add_argument('--output', type=Path, help='Machine directory; each selected series gets its own subfolder')
    parser.add_argument('--series', help='Comma-separated subset; default machine/model series')
    parser.add_argument('--max-cpu-cores', type=int)
    parser.add_argument('--max-gpus', type=int)
    parser.add_argument('--model', choices=tuple(MODEL_FOLDERS), help='Model for a new suite; default hydrostatic')
    parser.add_argument('--execution-mode', choices=('baseline', 'dagger'),
                        help='Direct execution or one local Dagger task per timing window')
    parser.add_argument('--compare-with', action='append', type=Path, default=[], help='Other-model suite; earlier paths take precedence for whole series')
    parser.add_argument('--comparison-report', type=Path, help='Markdown comparison refreshed alongside this suite')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--plan', action='store_true', help='Write configurations without executing or submitting')
    mode.add_argument('--run', action='store_true', help='Run locally inside assigned resources')
    mode.add_argument('--submit', action='store_true', help='Submit allocation groups through Slurm')
    mode.add_argument('--refresh', action='store_true', help='Refresh an existing suite and regenerate reports')
    mode.add_argument('--resume', action='store_true', help='Execute remaining PLANNED cases; never resubmit live jobs')
    parser.add_argument('--watch', action='store_true', help='Refresh until all cases finish; useful with --submit')
    parser.add_argument('--commit', action='store_true', help='Commit newly completed outcomes; requires configured Git identity')
    parser.add_argument('--revalidate', action='store_true', help='Validate completed artifacts again when refreshing')
    parser.add_argument('--publish', type=Path, help='Copy latest completed measurements into a curated machine directory')
    args = parser.parse_args()
    if (args.refresh or args.resume) and not args.output:
        parser.error('--refresh/--resume requires --output')
    if args.watch and args.plan:
        parser.error('--watch cannot be used with --plan')
    server = None if args.refresh or args.resume else load_server(args.config, args.model, args.execution_mode)
    selected = tuple(args.series.split(',')) if args.series else machine_series(server or {})
    if not selected or len(set(selected)) != len(selected) or set(selected) - set(ALL_SERIES):
        parser.error('Choose unique series names from: ' + ', '.join(ALL_SERIES))
    model_type = args.model or (server['model_type'] if server else 'HydrostaticFreeSurfaceModel')
    default_folder = None
    if server:
        if args.execution_mode:
            server['execution_mode'] = args.execution_mode
        scratch = os.environ.get('SCRATCH') or str(REPO / '.benchmark_scratch')
        default_folder = (Path(scratch) / 'benchmark_studies' /
                          MODEL_FOLDERS[model_type] /
                          (datetime.now(timezone.utc).strftime('%Y-%m-%dT%H%M%SZ') + '_' + str(os.getpid())) /
                          server['machine'])
        if not args.output and not args.publish:
            args.publish = ROOT / 'results' / MODEL_FOLDERS[model_type] / server['machine'] / server['execution_mode']
    machine_folder = (args.output or default_folder).resolve()
    if args.publish and args.publish.resolve() == machine_folder:
        parser.error('--publish must differ from the live study directory')
    machine_folder.mkdir(parents=True, exist_ok=True)
    if args.refresh or args.resume:
        available = {p.parent.name for p in machine_folder.glob('*/suite.json')}
        if not args.series:
            selected = tuple(s for s in ALL_SERIES if s in available)
        if not selected or set(selected) - available:
            parser.error('Selected series must exist in the machine directory')
    if server:
        if args.compare_with:
            server['comparison_suites'] = [str(p.resolve()) for p in args.compare_with]
        if args.comparison_report:
            server['comparison_report'] = str(args.comparison_report.resolve())
        if server['model_type'] == 'NonhydrostaticModel':
            server['reference_suites'] = []
            server['replacement_suites'] = []
        for key in ('max_cpu_cores', 'max_gpus'):
            value = getattr(args, key)
            if value is not None:
                server[key] = value
        if server['max_cpu_cores'] < 1 or server['max_gpus'] < 0:
            parser.error('Invalid resource capacity')
        if args.run:
            server['backend'] = 'local'
        if args.submit:
            if not args.config:
                parser.error('--submit requires a server config with explicit Slurm resource capacities')
            server['backend'] = 'slurm'
    with ExitStack() as stack:
        studies = []
        # Lock every selected series before changing any of them.
        for series in sorted(selected):
            folder = machine_folder / series
            folder.mkdir(parents=True, exist_ok=True)
            lock = stack.enter_context((folder / '.suite.lock').open('a'))
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            if not (args.refresh or args.resume) and (folder / 'suite.json').exists():
                raise ValueError('Series exists; use --resume/--refresh, or --output with a fresh machine directory')
        for series in selected:
            folder = machine_folder / series
            if args.refresh or args.resume:
                data = json.loads((folder / 'suite.json').read_text())
                if args.resume and data.get('curated'):
                    raise ValueError('Curated results are read-only; run a new study with --output in a fresh directory')
                if args.revalidate and data.get('curated'):
                    raise ValueError('Revalidate the original scratch study, where raw captures and execution evidence remain available')
                if args.revalidate:
                    for case in data['cases']:
                        case.pop('measurement', None)
            else:
                data = prepare(folder, server, (series,))
            data['commit'] = args.commit
            if args.publish:
                data['publish_to'] = str(args.publish.resolve())
            studies.append((folder, data))
            print('Series: ' + str(folder), flush=True)
            for case in data['cases']:
                print(f"{case['id']}: {case['state']} {case['partition'] or ''}", flush=True)
        write_machine_report(machine_folder)
        if args.plan:
            return
        if args.resume or not args.refresh:
            for folder, data in studies:
                execute(folder, data)
        committed = {folder: set() for folder, _ in studies}
        while True:
            done = True
            for folder, data in studies:
                finished = refresh(folder, data)
                done = done and finished
                outcomes = {(c['id'], c['state']) for c in data['cases'] if c['state'] in TERMINAL}
                write_machine_report(machine_folder)
                if data.get('publish_to'):
                    published = Path(data['publish_to'])
                    publish_series(folder, published / folder.name)
                    write_machine_report(published)
                if args.commit and (finished or outcomes - committed[folder]):
                    if data.get('publish_to'):
                        if (published / folder.name / 'suite.json').exists():
                            commit_artifacts(published / folder.name)
                    else:
                        commit_artifacts(folder)
                    committed[folder] = outcomes
            if done or not args.watch:
                break
            time.sleep(30)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, RuntimeError, BlockingIOError, FileNotFoundError, subprocess.TimeoutExpired) as error:
        raise SystemExit(str(error))
